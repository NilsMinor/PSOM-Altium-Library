PSOM module library for altium designer
# Nils Minor


Version 1.2 (15.11.2016)
# add 3D step blog again (Vergussmasse)
# updatated scheamtic symbol (correctet CANT mistake)

Version 1.1 (22.10.2016)

# removed 3D step blog above the module
# changed RSVD0 to MTS (Measurment Type Selection) which chooses a triggerd or auto measurment on PIN 9
# changed RSVD3 to EVT 3, event output pin on pin 20
# changed RSVD4 to EVT 4, event output pin on pin 21

Version 1 (17.10.2016)
# initial version

